
from gamelib import *
game = Game(800,600,"Delta Fighter")
bk = Image("field_5.png",game)
logo = Image("logo.png",game)
play = Image("play.png",game)
story = Image("story.png",game)
story.y = 200
storyImage = Image("storyImage.png",game)
howtoplay = Image("howtoplay.png",game)
asteroid = (Animation("asteroid1t.gif",41,game,2173/41,52))
howtoplay.y = 400
game.setBackground(bk)
#title screen
while not game.over:
    game.processInput()

    game.scrollBackground("down",2)
    logo.draw()
    
    game.update(60)
game.over =False
#Story
while not game.over:
    game.processInput()

    game.scrollBackground("down",2)
    storyImage.draw()

    game.update(60)
game.over =False
#Level 1
asteroids = []
for index in range(100):
    asteroids.append(Animation("asteroid1t.gif",41,game,2173/41,52))
for index in range(100):
    speed = randint(2,8)
    asteroids[index].setSpeed(speed,180)
    x = randint(100,700)
    y = randint(100,10000)
    asteroids[index].moveTo(x,-y)
    
while not game.over:
    game.processInput()
    game.scrollBackground("down",2)
    game.drawText("LEVEL 1",game.width-105,game.height-35)
    for index in range(100):
        asteroids[index].move()


    game.update(60)
game.over =False
